import sys
print sys.version.split("\n")[0]  
 
