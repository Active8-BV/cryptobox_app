# Contributed by Peter Burgers
# The matplotlib.numerix package sneaks these imports in under the radar:
hiddenimports = [
    'fft',
    'linear_algebra',
    'random_array',
    'ma',
    'mlab',
]

