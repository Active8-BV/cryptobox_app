hiddenimports = ["tables._comp_lzo", "tables._comp_bzip2"]
