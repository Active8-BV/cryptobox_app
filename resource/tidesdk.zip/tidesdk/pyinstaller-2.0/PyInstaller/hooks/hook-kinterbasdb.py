# Copyirght (C) 2005, Eugene Prigorodov
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA

# Courtesy of Eugene Prigorodov <eprigorodov at naumen dot ru>

#kinterbasdb
hiddenimports = ['k_exceptions', 'services', 'typeconv_naked',
                 'typeconv_backcompat', 'typeconv_23plus',
                 'typeconv_datetime_stdlib', 'typeconv_datetime_mx',
                 'typeconv_datetime_naked', 'typeconv_fixed_fixedpoint',
                 'typeconv_fixed_stdlib',  'typeconv_text_unicode',
                 'typeconv_util_isinstance', '_kinterbasdb', '_kiservices']
