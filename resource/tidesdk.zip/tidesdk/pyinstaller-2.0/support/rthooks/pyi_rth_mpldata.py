import os
import sys

os.environ["MATPLOTLIBDATA"] = os.path.join(sys._MEIPASS, "mpl-data")
