"""
import xml.etree.ElementTree
from copy import copy, deepcopy
import _elementtree
import xml.etree.cElementTree
print dir(xml.etree.cElementTree)
"""
from xml.etree.cElementTree import ElementTree
print "OK"
