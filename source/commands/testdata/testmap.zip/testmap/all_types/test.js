
function add(e, data) {
    var that = $(this).data('fileupload'),
        options = that.options,
        files = data.files;
    $(this).fileupload('process', data).done(function () {
        that._adjustMaxNumberOfFiles(-files.length);
        data.maxNumberOfFilesAdjusted = true;
        data.files.valid = data.isValidated = that._validate(files);
        data.context = that._renderUpload(files).data('data', data);
        options.filesContainer[
            options.prependFiles ? 'prepend' : 'append'
        ](data.context);
        that._renderPreviews(files, data.context);
        that._forceReflow(data.context);
        that._transition(data.context).done(
            function () {
                if ((that._trigger('added', e, data) !== false) &&
                        (options.autoUpload || data.autoUpload) &&
                        data.autoUpload !== false && data.isValidated) {
                    data.submit();
                }
            }
        );
    });
}
